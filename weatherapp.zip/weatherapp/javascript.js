$(document).ready(function(){

	$('#submitWeather').click(function(){

		var city = $("city").val();

		if(city !=''){

			$.ajax({

				url:'http://api.openweathermap.org/data/2.5/weather?q=' + city + "&units=metric" + "&appid=a09842d1e7c4c8d8d83db0e38aa624d7",
				type: "GET",
				dataType: "jsonp",
				success: function(data){
					console.log(data)
				
					var widget = show(data);

					$("#show").html(widget);
					$("city").val('');


				}


			});

		}else{
			$("#error").html('Field cannot be empty');

		}
	});
});

function show(data){
	return "<h2> <strong>Weather</strong>: "+ data.weather[0].main + "</h2>" + 
			"<h2> <strong>Temperature</strong>: "+ data.main.temp + "</h2>" +
			"<h2> <strong>Upcoming</strong>: "+ data.weather[1].description + "</h2>";
}