
//fuction to hide necessary elements
   $(document).ready(function() {
        $('#hidden1').hide();
        $('#hidden2').hide();
        $('#hiddensidebar').hide();
        $('#readless1').hide();
        $('#readless2').hide();
        $('#readlesssidebar').hide();
        $('#readlesssidebarbutton').hide();



    });

$(document).ready(function(){
        $('#readmore1button').click(function(){
         $("#hidden1").show();
         $("#readless1button").show();
         $("#readmore1button").hide();

  });
})


$(document).ready(function(){
        $('#readmore2button').click(function(){
         $("#hidden2").show();
         $("#readmore2button").hide();

  });
})

$(document).ready(function(){
        $('#readmoresidebarbutton').click(function(){
         $("#hiddensidebar").show();
         $("#readlesssidebarbutton").show();
         $("#readmoresidebarbutton").hide();

  });
})

$(document).ready(function(){
        $('#readless1button').click(function(){
         $("#hidden1").hide();
         $("#readless1button").hide();
         $("#readmore1button").show();

  });
})

$(document).ready(function(){
        $('#readless2button').click(function(){
         $("#hidden2").hide();
         $("#readless2button").hide();
         $("#readmore2button").show();

  });
})

$(document).ready(function(){
        $('readlesssidebarbutton').click(function(){
         $("#hiddensidebar").hide();
         $("#readlesssidebarbutton").hide();
         $("#readmoresidebarbutton").show();

  });
})







